
var newGame = Game()
newGame.start()
